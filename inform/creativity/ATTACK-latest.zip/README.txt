Please get the latest ATTACK at its github location:

https://github.com/i7/ATTACK

Thanks!